package factorymethod;

public interface Juoma {
}
