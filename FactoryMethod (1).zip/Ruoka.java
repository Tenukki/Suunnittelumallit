
package factorymethod;

public interface Ruoka {


}
